# irv-site 0.12.1 — Quem somos

Como instalar: envie o conteúdo desta pasta para `wp-content/plugins/irv-site/`
(mantendo as subpastas) e confirme a substituição de `irv-site.php`,
`assets/css/irv.css` e `assets/js/irv.js`. Os demais arquivos do plugin não mudam.

## Arquivos
- `templates/about.php` (novo): template próprio da página Quem somos.
- `irv-site.php`: versão 0.12.1, carrega `about.php` na rota Quem somos e a newsletter
  volta para a página de onde foi enviada.
- `assets/css/irv.css`: regras antigas intactas + bloco novo no final ("v0.12").
- `assets/js/irv.js`: acrescenta espaço antes de `<br>` (corrige palavras coladas no celular, inclusive na home).
- `assets/partners/*.png` (novos): 12 logos recortados da imagem composta do Wix. São provisórios.

## Parceiros
Em `templates/about.php`, o array `$partners` lista nome e arquivo. Para trocar um logo,
envie o arquivo para `assets/partners/` com o mesmo nome. Para incluir outro parceiro,
acrescente uma linha: sem arquivo, a vaga aparece reservada (tracejada).

## 0.12.1
- Seção "13 títulos": faixa clara e compacta (antes era um bloco azul grande).
- Parceiros: logos em largura total (4 por linha), maiores e sem esmaecer; logos recortados com fundo limpo.
- Documentos: cards pequenos em linha (ícone, nome, ano e "Baixar").

## 0.13.0 — demais páginas internas
- Novos templates: `work.php` (O que fazemos), `join.php` (Faça parte), `news.php` (Notícias), `post.php` (notícia, agora com "Leia também") e `privacy.php`.
- `templates/partials/` (head, header, footer, newsletter): cabeçalho, rodapé e newsletter iguais aos da home, compartilhados por todas as páginas internas, com o item do menu da página atual destacado.
- `irv-site.php`: cada rota carrega o seu template; `page.php` deixou de ser usado (fica no plugin como reserva).
- CSS (bloco v0.13): números de impacto sem sobreposição, hero de O que fazemos com a arte pronta, fotos das notícias sem esticar, formulário de doação sem linha cortando os títulos, textos de notícia e privacidade alinhados à esquerda.
- O `post.php` antigo foi substituído; o `page.php` antigo continua no servidor.

## 0.14.0 — O que fazemos no estilo do Wix + movimento
- Hero com a arte dentro do limite de largura da home, pincel rosa no canto e faixa cinza de topo inclinado logo abaixo (as pernas da menina terminam na diagonal, como no Wix).
- Metodologia com o texto completo, "habilidades socioemocionais" em azul, palavras-chave em negrito e setinha desenhada.
- Pilares: card branco, foto com ícone redondo, botão "Saiba mais" que abre o texto longo (acordeão acessível, um aberto por vez).
- Impacto: cards 01–04 com a foto inteira (sem cortar as pernas). O bloco azul de números (188/300/350/2200) deixou de aparecer nesta página, pois não existe no Wix.
- Movimento (todas as páginas internas): entrada ao rolar em cascata, números que contam (Faça parte), hover nos cards. Desligado em "reduzir movimento" e sem JavaScript tudo continua visível.

## 0.14.2 — Participantes e Nosso impacto (O que fazemos)
- Participantes: cards de retrato com a frase sobre a foto e etiqueta de nome e idade; no celular viram carrossel de deslizar. Fotos otimizadas em WebP (`assets/voices/`, 25–58 KB em vez de 4–5 MB).
- Nosso impacto: lista no estilo do Wix (numeral azul em degradê, fio com ponto rosa, foto de corte inclinado em fundo cinza), com hover e entrada em cascata.

## 0.14.3
- Nosso impacto: as quatro linhas têm sempre a mesma altura (a da maior), em qualquer tela.
- O que fazemos: o mesmo espaço (88 px no desktop, 64 no tablet, 52 no celular) em cima e embaixo de todas as seções.

## 0.14.4
- O que fazemos: removida a faixa "Fique por dentro" acima do rodapé (o Wix também não a tem nesta página) e a faixa de doação voltou a ser azul, com botão rosa.

## 0.14.5
- O que fazemos: espaço entre seções reduzido (56 px no desktop, 44 no tablet, 36 no celular), igual em todas. Ajuste pela variável `--sy` no CSS.

## 0.14.6
- O que fazemos: removida a pincelada rosa circular do canto do hero.

## 0.15.0 — Notícias modernas
- Página Notícias: cabeçalho centralizado ("Histórias em movimento"), filtros de categoria em pílulas centralizadas, a notícia mais recente em destaque (foto grande + resumo + botão) e os demais em cards com a foto ao fundo, etiquetas de categoria, data e "Ler matéria".
- Página de notícia: "Leia também" usa os mesmos cards.
- Fotos das notícias em WebP leve (`assets/news/`, 23–176 KB, antes até 7 MB). Funções de apoio em `templates/partials/news-helpers.php` (se a foto leve não existir, usa o original).

## 0.15.1
- Removido o "1 min de leitura" de todas as páginas (home, lista de notícias, destaque, cards, "Leia também" e página da notícia). `templates/home.php` agora também está no repositório.

## 0.15.2
- Home: o item "Notícias" do cabeçalho agora abre a página de notícias (antes rolava a página até a seção).

## 0.16.0 — Faça parte
- Hero em tela cheia com borda rasgada; "Existem muitas formas de *fazer parte*" com a letra manuscrita do Wix; 3 cartões com os ícones do Wix (doação, parcerias, materiais). O cartão "Seja voluntário" foi excluído.
- Doação interativa: frequência (1 vez/mensal), valores e "Outro"; o botão mostra "Doar R$ X" e abre um e-mail com o valor escolhido (o pagamento ainda não está conectado).
- Depoimentos: cards com pôster; tocam vídeo ao clicar quando o arquivo MP4 existir em `assets/videos/` (`depoimento-paulo.mp4`, `depoimento-ludmila.mp4`, `depoimento-clarissa.mp4`).
- Galeria em mosaico com visualizador de foto e vídeo (`assets/gallery/`, itens listados em `templates/join.php`).
- Entrada ao rolar, valores contando e hover nos cards.
